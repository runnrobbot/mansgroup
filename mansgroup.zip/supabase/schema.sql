-- ============================================================
-- MANSGROUP FINTECH — Supabase PostgreSQL Schema
-- Run this in the Supabase SQL Editor
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- PROFILES (extends Supabase auth.users)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email           TEXT,
  full_name       TEXT,
  phone           TEXT,
  address         TEXT,
  nik             TEXT,
  birth_place     TEXT,
  birth_date      DATE,
  occupation      TEXT,
  income          BIGINT,
  role            TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','staff','admin','founder')),
  kyc_status      TEXT NOT NULL DEFAULT 'unverified' CHECK (kyc_status IN ('unverified','pending','verified','rejected')),
  reward_eligible BOOLEAN DEFAULT FALSE,
  is_blacklisted  BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, phone)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'phone'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- KYC DOCUMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.kyc_documents (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  ktp_photo_url   TEXT,
  selfie_ktp_url  TEXT,
  selfie_url      TEXT,
  kk_url          TEXT,
  ktm_url         TEXT,
  pddikti_url     TEXT,
  nim             TEXT,
  campus_name     TEXT,
  status          TEXT DEFAULT 'pending' CHECK (status IN ('pending','verified','rejected')),
  review_notes    TEXT,
  submitted_at    TIMESTAMPTZ DEFAULT NOW(),
  reviewed_at     TIMESTAMPTZ,
  reviewed_by     UUID REFERENCES public.profiles(id),
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- ============================================================
-- LOANS (MansLater)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.loans (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ref_number           TEXT UNIQUE NOT NULL,
  user_id              UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  amount               BIGINT NOT NULL,
  tenor                INTEGER NOT NULL CHECK (tenor IN (1,3,6,9)),
  interest_rate        DECIMAL(5,4) DEFAULT 0.05,
  total_interest       BIGINT,
  platform_fee         BIGINT,
  net_disbursement     BIGINT,
  total_repayment      BIGINT,
  monthly_installment  BIGINT,
  remaining_amount     BIGINT,
  bank_code            TEXT,
  account_number       TEXT,
  account_name         TEXT,
  user_type            TEXT DEFAULT 'worker',
  full_name            TEXT,
  nik                  TEXT,
  birth_place          TEXT,
  birth_date           DATE,
  address              TEXT,
  occupation           TEXT,
  income               BIGINT,
  phone                TEXT,
  emergency_name       TEXT,
  emergency_phone      TEXT,
  emergency_relation   TEXT,
  nim                  TEXT,
  campus_name          TEXT,
  ktp_photo_url        TEXT,
  selfie_ktp_url       TEXT,
  selfie_url           TEXT,
  kk_url               TEXT,
  ktm_url              TEXT,
  pddikti_url          TEXT,
  status               TEXT DEFAULT 'pending' CHECK (status IN ('pending','review','approved','rejected','disbursed','overdue','completed','blacklisted')),
  staff_notes          TEXT,
  reviewed_by          UUID REFERENCES public.profiles(id),
  approved_at          TIMESTAMPTZ,
  disbursed_at         TIMESTAMPTZ,
  due_date             DATE,
  completed_at         TIMESTAMPTZ,
  created_at           TIMESTAMPTZ DEFAULT NOW(),
  updated_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- LOAN SCHEDULES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.loan_schedules (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  loan_id     UUID REFERENCES public.loans(id) ON DELETE CASCADE,
  month       INTEGER NOT NULL,
  due_date    DATE NOT NULL,
  principal   BIGINT,
  interest    BIGINT,
  total       BIGINT,
  paid_amount BIGINT DEFAULT 0,
  status      TEXT DEFAULT 'pending' CHECK (status IN ('pending','paid','overdue')),
  paid_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- GADAI APPLICATIONS (MansGadai)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.gadai_applications (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ref_number       TEXT UNIQUE NOT NULL,
  user_id          UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  item_name        TEXT,
  item_category    TEXT,
  item_description TEXT,
  item_photo_url   TEXT,
  loan_amount      BIGINT NOT NULL,
  interest         BIGINT,
  platform_fee     BIGINT,
  net_disbursement BIGINT,
  total_repayment  BIGINT,
  extension_fee    BIGINT,
  bank_code        TEXT,
  account_number   TEXT,
  account_name     TEXT,
  pickup_address   TEXT,
  pickup_schedule  TIMESTAMPTZ,
  status           TEXT DEFAULT 'pending' CHECK (status IN ('pending','review','approved','rejected','waiting_pickup','picked_up','received','active','due','extended','overdue','completed','forfeited')),
  staff_notes      TEXT,
  reviewed_by      UUID REFERENCES public.profiles(id),
  due_date         DATE,
  extended_until   DATE,
  extension_count  INTEGER DEFAULT 0,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PICKUP SCHEDULES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.pickup_schedules (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  gadai_id        UUID REFERENCES public.gadai_applications(id) ON DELETE CASCADE,
  scheduled_at    TIMESTAMPTZ,
  address         TEXT,
  assigned_staff  UUID REFERENCES public.profiles(id),
  status          TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_transit','completed','cancelled')),
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- COLLATERAL ITEMS (Warehouse)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.collateral_items (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  gadai_id         UUID REFERENCES public.gadai_applications(id) ON DELETE SET NULL,
  inventory_code   TEXT UNIQUE,
  item_name        TEXT,
  category         TEXT,
  condition        TEXT,
  description      TEXT,
  photo_url        TEXT,
  estimated_value  BIGINT,
  storage_location TEXT,
  status           TEXT DEFAULT 'stored' CHECK (status IN ('stored','returned','forfeited','damaged')),
  received_at      TIMESTAMPTZ DEFAULT NOW(),
  returned_at      TIMESTAMPTZ,
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PAYMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.payments (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id              UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  loan_id              UUID REFERENCES public.loans(id) ON DELETE SET NULL,
  gadai_id             UUID REFERENCES public.gadai_applications(id) ON DELETE SET NULL,
  schedule_id          UUID REFERENCES public.loan_schedules(id) ON DELETE SET NULL,
  amount               BIGINT NOT NULL,
  payment_type         TEXT DEFAULT 'repayment' CHECK (payment_type IN ('repayment','extension','late_fee','refund')),
  payment_method       TEXT,
  proof_url            TEXT,
  status               TEXT DEFAULT 'pending' CHECK (status IN ('pending','verification','confirmed','failed','refunded')),
  verified_by          UUID REFERENCES public.profiles(id),
  verification_notes   TEXT,
  verified_at          TIMESTAMPTZ,
  created_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- DOCUMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.documents (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  entity_type   TEXT NOT NULL,
  entity_id     UUID,
  doc_type      TEXT NOT NULL,
  file_url      TEXT NOT NULL,
  file_name     TEXT,
  file_size     INTEGER,
  uploaded_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- BLACKLISTS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.blacklists (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  reason      TEXT NOT NULL,
  type        TEXT DEFAULT 'overdue' CHECK (type IN ('overdue','fraud','default','other')),
  is_active   BOOLEAN DEFAULT TRUE,
  added_by    UUID REFERENCES public.profiles(id),
  added_at    TIMESTAMPTZ DEFAULT NOW(),
  removed_by  UUID REFERENCES public.profiles(id),
  removed_at  TIMESTAMPTZ
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  type        TEXT NOT NULL,
  title       TEXT NOT NULL,
  message     TEXT,
  metadata    JSONB DEFAULT '{}',
  is_read     BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- AUDIT LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  action       TEXT NOT NULL,
  entity_type  TEXT,
  entity_id    UUID,
  metadata     JSONB DEFAULT '{}',
  ip_address   TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES for performance
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_loans_user_id ON public.loans(user_id);
CREATE INDEX IF NOT EXISTS idx_loans_status ON public.loans(status);
CREATE INDEX IF NOT EXISTS idx_gadai_user_id ON public.gadai_applications(user_id);
CREATE INDEX IF NOT EXISTS idx_gadai_status ON public.gadai_applications(status);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON public.payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_loan_id ON public.payments(loan_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON public.notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON public.audit_logs(user_id);

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gadai_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kyc_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blacklists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.collateral_items ENABLE ROW LEVEL SECURITY;

-- Helper function to get current user role
CREATE OR REPLACE FUNCTION public.get_user_role()
RETURNS TEXT LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid()
$$;

-- PROFILES policies
CREATE POLICY "users_read_own_profile" ON public.profiles FOR SELECT USING (auth.uid() = id OR get_user_role() IN ('staff','admin','founder'));
CREATE POLICY "users_update_own_profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "admin_manage_profiles" ON public.profiles FOR ALL USING (get_user_role() IN ('admin','founder'));

-- LOANS policies
CREATE POLICY "users_read_own_loans" ON public.loans FOR SELECT USING (auth.uid() = user_id OR get_user_role() IN ('staff','admin','founder'));
CREATE POLICY "users_create_loans" ON public.loans FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "staff_update_loans" ON public.loans FOR UPDATE USING (get_user_role() IN ('staff','admin','founder'));

-- GADAI policies
CREATE POLICY "users_read_own_gadai" ON public.gadai_applications FOR SELECT USING (auth.uid() = user_id OR get_user_role() IN ('staff','admin','founder'));
CREATE POLICY "users_create_gadai" ON public.gadai_applications FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "staff_update_gadai" ON public.gadai_applications FOR UPDATE USING (get_user_role() IN ('staff','admin','founder'));

-- PAYMENTS policies
CREATE POLICY "users_read_own_payments" ON public.payments FOR SELECT USING (auth.uid() = user_id OR get_user_role() IN ('staff','admin','founder'));
CREATE POLICY "users_create_payments" ON public.payments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "staff_verify_payments" ON public.payments FOR UPDATE USING (get_user_role() IN ('staff','admin','founder'));

-- NOTIFICATIONS policies
CREATE POLICY "users_read_own_notifs" ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "users_update_own_notifs" ON public.notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "system_insert_notifs" ON public.notifications FOR INSERT WITH CHECK (get_user_role() IN ('staff','admin','founder') OR auth.uid() = user_id);

-- KYC policies
CREATE POLICY "users_read_own_kyc" ON public.kyc_documents FOR SELECT USING (auth.uid() = user_id OR get_user_role() IN ('staff','admin','founder'));
CREATE POLICY "users_submit_kyc" ON public.kyc_documents FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "users_update_own_kyc" ON public.kyc_documents FOR UPDATE USING (auth.uid() = user_id OR get_user_role() IN ('staff','admin','founder'));

-- DOCUMENTS policies
CREATE POLICY "users_read_own_docs" ON public.documents FOR SELECT USING (auth.uid() = user_id OR get_user_role() IN ('staff','admin','founder'));
CREATE POLICY "users_upload_docs" ON public.documents FOR INSERT WITH CHECK (auth.uid() = user_id);

-- BLACKLIST policies
CREATE POLICY "admin_manage_blacklist" ON public.blacklists FOR ALL USING (get_user_role() IN ('admin','founder'));
CREATE POLICY "staff_read_blacklist" ON public.blacklists FOR SELECT USING (get_user_role() IN ('staff','admin','founder'));

-- AUDIT LOGS policies
CREATE POLICY "admin_read_audit" ON public.audit_logs FOR SELECT USING (get_user_role() IN ('admin','founder'));
CREATE POLICY "system_write_audit" ON public.audit_logs FOR INSERT WITH CHECK (TRUE);

-- COLLATERAL policies
CREATE POLICY "staff_manage_collateral" ON public.collateral_items FOR ALL USING (get_user_role() IN ('staff','admin','founder'));

-- ============================================================
-- STORAGE BUCKETS (run separately or via Supabase dashboard)
-- ============================================================
-- INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);

-- ============================================================
-- REALTIME (enable for notifications)
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.loans;
ALTER PUBLICATION supabase_realtime ADD TABLE public.gadai_applications;
